package competition.persistence;


//public interface ITestAgeCategoryRepository <ID, T extends HasId<ID>> extends IRepository<ID, T>{
//}

import competition.model.TestAgeCategory;

public interface ITestAgeCategoryRepository extends IRepository<Integer, TestAgeCategory>{
}
