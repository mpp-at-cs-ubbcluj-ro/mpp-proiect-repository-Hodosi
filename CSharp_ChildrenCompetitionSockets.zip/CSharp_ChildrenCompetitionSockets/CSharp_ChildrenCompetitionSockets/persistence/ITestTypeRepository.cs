﻿using CSharp_ChildrenCompetitionGUI.model;

namespace CSharp_ChildrenCompetitionGUI.repository
{
    public interface ITestTypeRepository : IRepository<int, TestType>
    {
        
    }
}