﻿using CSharp_ChildrenCompetitionGUI.model;

namespace CSharp_ChildrenCompetitionGUI.repository
{
    public interface ITestAgeCategoryRepository : IRepository<int, TestAgeCategory>
    {
        
    }
}