﻿namespace persistence
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}