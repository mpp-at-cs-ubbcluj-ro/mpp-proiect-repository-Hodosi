﻿namespace networking
{
    internal class Program
    {
        public static void Main(string[] args)
        {
        }
    }
}