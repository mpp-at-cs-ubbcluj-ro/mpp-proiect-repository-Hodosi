﻿namespace client
{
    public class StartCompetitionClient
    {
        
    }
}