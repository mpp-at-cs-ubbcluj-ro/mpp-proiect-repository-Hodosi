﻿using System;

namespace CSharp_ChildrenCompetitionGUI.model
{
    [Serializable]
    public class TestParticipantRelation : HasId<Tuple<int, int>>
    {
        public Tuple<int, int> id { get; set; }

        public TestParticipantRelation(Tuple<int, int> id)
        {
            this.id = id;
        }
    }
}