﻿namespace CSharp_ChildrenCompetitionGUI.model
{
    public interface HasId <ID>
    {
        ID id { get; set; }
    }
}